document.write('<script src="js/utils/ajax.js"></script>');
document.write('<script src="js/utils/domHelpers.js"></script>');
document.write('<script src="js/main.js"></script>');
document.write('<link rel="stylesheet" type="text/css" href="css/weatherTile.css">'); 